import { useMemo } from "react";
import * as THREE from "three";
import type { LandmarkFrame } from "../../types/landmarks";
import { createRigFrame, type RigFrame } from "./landmarkRig";

type LimbProps = {
  color: string;
  end: THREE.Vector3;
  radius: number;
  start: THREE.Vector3;
};

const Y_AXIS = new THREE.Vector3(0, 1, 0);
const SKIN = "#b8795a";
const SKIN_LIGHT = "#d59a74";
const SHIRT = "#3f6d82";
const SHIRT_DARK = "#2f5061";
const HAIR = "#201818";
const EYE = "#141414";
const WHITE = "#fff7ea";

function midpoint(start: THREE.Vector3, end: THREE.Vector3) {
  return start.clone().add(end).multiplyScalar(0.5);
}

function average(points: THREE.Vector3[]) {
  return points
    .reduce((total, point) => total.add(point), new THREE.Vector3())
    .divideScalar(points.length || 1);
}

function Limb({ color, end, radius, start }: LimbProps) {
  const direction = end.clone().sub(start);
  const length = direction.length();
  if (length < 0.01) {
    return null;
  }

  const quaternion = new THREE.Quaternion().setFromUnitVectors(
    Y_AXIS,
    direction.clone().normalize(),
  );

  return (
    <group>
      <mesh position={midpoint(start, end)} quaternion={quaternion} scale={[radius, length, radius]}>
        <cylinderGeometry args={[1, 1, 1, 14, 1]} />
        <meshStandardMaterial color={color} roughness={0.7} />
      </mesh>
      <JointSphere color={color} position={start} radius={radius} />
      <JointSphere color={color} position={end} radius={radius} />
    </group>
  );
}

function JointSphere({
  color,
  position,
  radius,
}: {
  color: string;
  position: THREE.Vector3;
  radius: number;
}) {
  return (
    <mesh position={position} scale={radius}>
      <sphereGeometry args={[1, 18, 14]} />
      <meshStandardMaterial color={color} roughness={0.72} />
    </mesh>
  );
}

function Ellipsoid({
  color,
  position,
  roughness = 0.72,
  scale,
}: {
  color: string;
  position: THREE.Vector3;
  roughness?: number;
  scale: [number, number, number];
}) {
  return (
    <mesh position={position} scale={scale}>
      <sphereGeometry args={[1, 32, 24]} />
      <meshStandardMaterial color={color} roughness={roughness} />
    </mesh>
  );
}

function RoundedBox({
  color,
  position,
  roughness = 0.8,
  scale,
}: {
  color: string;
  position: THREE.Vector3;
  roughness?: number;
  scale: [number, number, number];
}) {
  return (
    <mesh position={position} scale={scale}>
      <boxGeometry args={[1, 1, 1, 3, 8, 3]} />
      <meshStandardMaterial color={color} roughness={roughness} />
    </mesh>
  );
}

function UpperBody({ rig }: { rig: RigFrame }) {
  const chestCenter = rig.chest.clone().lerp(rig.hips, 0.43);
  const shoulderCenter = midpoint(rig.leftShoulder, rig.rightShoulder);
  const torsoWidth = Math.max(rig.shoulderWidth * 0.64, 0.5);
  const torsoHeight = Math.max(rig.torsoHeight * 0.62, 0.78);
  const neck = rig.chest.clone().lerp(rig.head, 0.32);

  return (
    <>
      <RoundedBox
        color={SHIRT}
        position={chestCenter.clone().add(new THREE.Vector3(0, -0.08, 0))}
        roughness={0.82}
        scale={[torsoWidth, torsoHeight, 0.26]}
      />
      <Ellipsoid
        color={SHIRT_DARK}
        position={shoulderCenter.clone().add(new THREE.Vector3(0, -0.05, -0.015))}
        roughness={0.86}
        scale={[torsoWidth * 1.1, 0.2, 0.2]}
      />
      <Ellipsoid color={SKIN} position={neck} scale={[0.13, 0.2, 0.12]} />
      <mesh position={rig.chest.clone().lerp(rig.hips, 0.18).add(new THREE.Vector3(0, -0.02, 0.19))}>
        <coneGeometry args={[0.18, 0.24, 3]} />
        <meshStandardMaterial color={WHITE} roughness={0.78} />
      </mesh>
      <Limb color={SHIRT_DARK} end={rig.leftShoulder} radius={0.105} start={shoulderCenter} />
      <Limb color={SHIRT_DARK} end={rig.rightShoulder} radius={0.105} start={shoulderCenter} />
    </>
  );
}

function Face({ headCenter }: { headCenter: THREE.Vector3 }) {
  const faceZ = 0.18;
  const eyeY = 0.045;

  return (
    <group position={headCenter}>
      <Ellipsoid
        color={WHITE}
        position={new THREE.Vector3(-0.065, eyeY, faceZ)}
        scale={[0.034, 0.05, 0.012]}
      />
      <Ellipsoid
        color={WHITE}
        position={new THREE.Vector3(0.065, eyeY, faceZ)}
        scale={[0.034, 0.05, 0.012]}
      />
      <JointSphere color={EYE} position={new THREE.Vector3(-0.058, eyeY - 0.005, faceZ + 0.012)} radius={0.014} />
      <JointSphere color={EYE} position={new THREE.Vector3(0.072, eyeY - 0.005, faceZ + 0.012)} radius={0.014} />
      <Limb
        color={HAIR}
        end={new THREE.Vector3(-0.02, -0.015, faceZ + 0.02)}
        radius={0.009}
        start={new THREE.Vector3(0.012, 0.014, faceZ + 0.02)}
      />
      <Limb
        color="#7c4330"
        end={new THREE.Vector3(0.07, -0.095, faceZ + 0.015)}
        radius={0.009}
        start={new THREE.Vector3(-0.07, -0.095, faceZ + 0.015)}
      />
      <Limb
        color={HAIR}
        end={new THREE.Vector3(-0.02, 0.13, faceZ + 0.01)}
        radius={0.007}
        start={new THREE.Vector3(-0.105, 0.11, faceZ + 0.01)}
      />
      <Limb
        color={HAIR}
        end={new THREE.Vector3(0.105, 0.11, faceZ + 0.01)}
        radius={0.007}
        start={new THREE.Vector3(0.02, 0.13, faceZ + 0.01)}
      />
    </group>
  );
}

function Head({ rig }: { rig: RigFrame }) {
  const headCenter = rig.head.clone().add(new THREE.Vector3(0, 0.15, 0));

  return (
    <>
      <JointSphere color={SKIN_LIGHT} position={headCenter.clone().add(new THREE.Vector3(-0.2, -0.01, 0))} radius={0.045} />
      <JointSphere color={SKIN_LIGHT} position={headCenter.clone().add(new THREE.Vector3(0.2, -0.01, 0))} radius={0.045} />
      <Ellipsoid color={SKIN_LIGHT} position={headCenter} roughness={0.68} scale={[0.19, 0.24, 0.18]} />
      <mesh position={headCenter.clone().add(new THREE.Vector3(0, 0.11, -0.015))} scale={[0.196, 0.11, 0.19]}>
        <sphereGeometry args={[1, 32, 14, 0, Math.PI * 2, 0, Math.PI * 0.62]} />
        <meshStandardMaterial color={HAIR} roughness={0.78} />
      </mesh>
      <Face headCenter={headCenter} />
    </>
  );
}

function FingerChain({
  chainId,
  color,
  points,
  radius,
}: {
  chainId: string;
  color: string;
  points: THREE.Vector3[];
  radius: number;
}) {
  const tip = points.at(-1);

  if (points.length < 2 || !tip) {
    return null;
  }

  const curve = new THREE.CatmullRomCurve3(
    points.map((point) => point.clone()),
    false,
    "centripetal",
    0.25,
  );

  return (
    <>
      <mesh key={`${chainId}-tube`}>
        <tubeGeometry args={[curve, 22, radius, 14, false]} />
        <meshStandardMaterial color={color} roughness={0.68} />
      </mesh>
      <Ellipsoid
        color={SKIN_LIGHT}
        position={tip}
        scale={[radius * 1.05, radius * 1.22, radius * 1.05]}
      />
    </>
  );
}

function makeHandDisplayPoints(points: THREE.Vector3[], center: THREE.Vector3) {
  return points.map((point) =>
    center
      .clone()
      .add(point.clone().sub(center).multiplyScalar(1.82))
      .add(new THREE.Vector3(0, 0.03, 0.72)),
  );
}

function LandmarkHand({
  handedness,
  points,
  wrist,
}: {
  handedness: "left" | "right";
  points: THREE.Vector3[];
  wrist: THREE.Vector3;
}) {
  if (points.length < 21) {
    return <JointSphere color={SKIN_LIGHT} position={wrist} radius={0.082} />;
  }

  const chains = [
    [0, 1, 2, 3, 4],
    [0, 5, 6, 7, 8],
    [0, 9, 10, 11, 12],
    [0, 13, 14, 15, 16],
    [0, 17, 18, 19, 20],
  ];
  const palmCenter = average([points[0], points[5], points[9], points[13], points[17]]);
  const displayPoints = makeHandDisplayPoints(points, palmCenter);
  const displayPalmCenter = average([
    displayPoints[0],
    displayPoints[5],
    displayPoints[9],
    displayPoints[13],
    displayPoints[17],
  ]);
  const displayWrist = wrist
    .clone()
    .lerp(points[0], 0.38)
    .add(new THREE.Vector3(0, 0.02, 0.56));

  return (
    <>
      <Ellipsoid color={SKIN_LIGHT} position={displayPalmCenter} scale={[0.135, 0.1, 0.07]} />
      <Limb color={SKIN_LIGHT} end={displayPoints[0]} radius={0.052} start={displayWrist} />
      {chains.map((chain) => (
        <FingerChain
          chainId={`${handedness}-${chain.join("-")}`}
          color={SKIN_LIGHT}
          key={chain.join("-")}
          points={chain.map((index) => displayPoints[index])}
          radius={0.034}
        />
      ))}
    </>
  );
}

function Arms({ rig }: { rig: RigFrame }) {
  return (
    <>
      <Limb color={SKIN} end={rig.leftElbow} radius={0.083} start={rig.leftShoulder} />
      <Limb color={SKIN_LIGHT} end={rig.leftWrist} radius={0.072} start={rig.leftElbow} />
      <Limb color={SKIN} end={rig.rightElbow} radius={0.083} start={rig.rightShoulder} />
      <Limb color={SKIN_LIGHT} end={rig.rightWrist} radius={0.072} start={rig.rightElbow} />
      <LandmarkHand handedness="left" points={rig.leftHand} wrist={rig.leftWrist} />
      <LandmarkHand handedness="right" points={rig.rightHand} wrist={rig.rightWrist} />
    </>
  );
}

export function ProceduralHumanoid({ frame }: { frame: LandmarkFrame }) {
  const rig = useMemo(() => createRigFrame(frame), [frame]);

  return (
    <group position={[0, -0.92, 0]}>
      <UpperBody rig={rig} />
      <Head rig={rig} />
      <Arms rig={rig} />
    </group>
  );
}
