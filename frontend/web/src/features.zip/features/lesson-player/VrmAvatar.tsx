import { useFrame, useLoader } from "@react-three/fiber";
import { useEffect, useMemo } from "react";
import * as THREE from "three";
import { GLTF, GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import {
  VRM,
  VRMHumanBoneName,
  VRMLoaderPlugin,
  type VRMPose,
} from "@pixiv/three-vrm";
import type { LandmarkFrame } from "../../types/landmarks";
import {
  createRigFrame,
  quaternionTuple,
  rotationFromDirection,
} from "./landmarkRig";

type VrmGltf = GLTF & {
  userData: {
    vrm?: VRM;
  };
};

const LEFT_REST = new THREE.Vector3(1, 0, 0);
const RIGHT_REST = new THREE.Vector3(-1, 0, 0);
const DOWN_REST = new THREE.Vector3(0, -1, 0);

function boneRotation(
  restDirection: THREE.Vector3,
  start: THREE.Vector3,
  end: THREE.Vector3,
) {
  return quaternionTuple(rotationFromDirection(restDirection, end.clone().sub(start)));
}

function createVrmPose(frame: LandmarkFrame): VRMPose {
  const rig = createRigFrame(frame);
  const pose: VRMPose = {
    [VRMHumanBoneName.LeftUpperArm]: {
      rotation: boneRotation(LEFT_REST, rig.leftShoulder, rig.leftElbow),
    },
    [VRMHumanBoneName.LeftLowerArm]: {
      rotation: boneRotation(LEFT_REST, rig.leftElbow, rig.leftWrist),
    },
    [VRMHumanBoneName.RightUpperArm]: {
      rotation: boneRotation(RIGHT_REST, rig.rightShoulder, rig.rightElbow),
    },
    [VRMHumanBoneName.RightLowerArm]: {
      rotation: boneRotation(RIGHT_REST, rig.rightElbow, rig.rightWrist),
    },
    [VRMHumanBoneName.Spine]: {
      rotation: quaternionTuple(
        rotationFromDirection(DOWN_REST, rig.hips.clone().sub(rig.chest)).slerp(
          new THREE.Quaternion(),
          0.72,
        ),
      ),
    },
  };

  return pose;
}

export function VrmAvatar({
  frame,
  modelUrl,
}: {
  frame: LandmarkFrame;
  modelUrl: string;
}) {
  const gltf = useLoader(
    GLTFLoader,
    modelUrl,
    (loader) => {
      loader.register((parser) => new VRMLoaderPlugin(parser));
    },
  ) as VrmGltf;

  const vrm = gltf.userData.vrm;
  const pose = useMemo(() => createVrmPose(frame), [frame]);

  useEffect(() => {
    if (!vrm) {
      return;
    }
    vrm.scene.rotation.y = Math.PI;
    vrm.scene.traverse((object) => {
      object.frustumCulled = false;
    });
  }, [vrm]);

  useFrame((_, delta) => {
    if (!vrm) {
      return;
    }
    vrm.humanoid.setNormalizedPose(pose);
    vrm.update(delta);
  });

  if (!vrm) {
    return null;
  }

  return <primitive object={vrm.scene} position={[0, -0.95, 0]} />;
}
