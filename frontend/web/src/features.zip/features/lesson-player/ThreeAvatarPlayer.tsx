import { Canvas } from "@react-three/fiber";
import { lazy, Suspense, useEffect, useState } from "react";
import { RenderErrorBoundary } from "../../components/RenderErrorBoundary";
import type { LandmarkFrame } from "../../types/landmarks";
import { ProceduralHumanoid } from "./ProceduralHumanoid";

const DEFAULT_MODEL_URL = "/models/avatar.vrm";
const LazyVrmAvatar = lazy(() =>
  import("./VrmAvatar").then((module) => ({ default: module.VrmAvatar })),
);

function useWebGlAvailable() {
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null);

  useEffect(() => {
    const canvas = document.createElement("canvas");
    const gl =
      canvas.getContext("webgl2") ??
      canvas.getContext("webgl") ??
      canvas.getContext("experimental-webgl");
    setIsAvailable(Boolean(gl));
  }, []);

  return isAvailable;
}

function useAvailableModelUrl(modelUrl: string) {
  const [availableUrl, setAvailableUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    fetch(modelUrl, { cache: "no-store", method: "HEAD" })
      .then((response) => {
        if (cancelled) {
          return;
        }

        const contentType = response.headers.get("content-type")?.toLowerCase() ?? "";
        const isHtmlFallback = contentType.includes("text/html");
        setAvailableUrl(response.ok && !isHtmlFallback ? modelUrl : null);
      })
      .catch(() => {
        if (!cancelled) {
          setAvailableUrl(null);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [modelUrl]);

  return availableUrl;
}

function StageLights() {
  return (
    <>
      <ambientLight intensity={1.25} />
      <directionalLight
        intensity={2.3}
        position={[2.8, 4.2, 4.5]}
      />
      <hemisphereLight args={["#edf7ff", "#283737", 0.9]} />
    </>
  );
}

function Backdrop() {
  return (
    <mesh position={[0, 0.92, -1.1]}>
      <circleGeometry args={[2.15, 64]} />
      <meshBasicMaterial color="#e6eee9" transparent opacity={0.55} />
    </mesh>
  );
}

function ModelOrFallback({
  frame,
  modelUrl,
}: {
  frame: LandmarkFrame;
  modelUrl: string | null;
}) {
  if (!modelUrl) {
    return <ProceduralHumanoid frame={frame} />;
  }

  return (
    <Suspense fallback={<ProceduralHumanoid frame={frame} />}>
      <LazyVrmAvatar frame={frame} modelUrl={modelUrl} />
    </Suspense>
  );
}

export function ThreeAvatarPlayer({ frame }: { frame: LandmarkFrame }) {
  const modelUrl = useAvailableModelUrl(DEFAULT_MODEL_URL);
  const webGlAvailable = useWebGlAvailable();

  if (webGlAvailable === null) {
    return (
      <div className="three-stage three-stage-error">
        <strong>Preparing 3D preview...</strong>
      </div>
    );
  }

  if (!webGlAvailable) {
    return (
      <div className="three-stage three-stage-error" role="alert">
        <strong>WebGL is not available.</strong>
        <span>This browser cannot start the 3D avatar renderer.</span>
      </div>
    );
  }

  return (
    <RenderErrorBoundary
      fallback={(error) => (
        <div className="three-stage three-stage-error" role="alert">
          <strong>3D preview could not start.</strong>
          <span>{error.message}</span>
        </div>
      )}
      resetKey={modelUrl ?? "procedural-fallback"}
    >
      <div className="three-stage">
        <Canvas
          camera={{ fov: 40, position: [0, 1.18, 5.15] }}
          dpr={[1, 1.5]}
          gl={{ antialias: true, powerPreference: "high-performance" }}
        >
          <color attach="background" args={["#f8faf9"]} />
          <StageLights />
          <Backdrop />
          <group position={[0, 0, -0.9]}>
            <ModelOrFallback frame={frame} modelUrl={modelUrl} />
          </group>
        </Canvas>
      </div>
    </RenderErrorBoundary>
  );
}
